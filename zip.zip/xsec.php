<?php

/**
 * Admin finder Scanner | galehdotid
 * thx   : Indoxploit - xaisyndicate - all indonesia Hacker Rulez
 * Open Result : admin-login.txt !
 * Usage :  Usage : php admin
 */
error_reporting(0);
$green2="\033[1;32m";
$putih="\033[0;37m";
$d = "https://zone-xsec.com/archive/attacker/";
$s = "https://zone-xsec.com/special/page=";
$n = "https://zone-xsec.com/onhold/page=";
$t = "https://zone-xsec.com/archive/team/";
echo "{$green2} 	___________________________
	< root@indoxploit:~# Zone-Xsec >
	 ---------------------------
	   \         ,        ,
	    \       /(        )`
	     \      \ \___   / |
	            /- _  `-/  '
	           (/\/ \ \   /\
	           / /   | `    \
	           O O   ) /    |
	           `-^--'`<     '
	          (_.)  _  )   /
	           `.___/`    /
	             `-----' /
	<----.     __ / __   \
	<----|====O)))==) \) /====>
	<----'    `--' `.__,' \
	             |        |
	              \       /
	        ______( (_  / \______
	      ,'  ,-----'   |        \
	      `--{__________)        \/
\r\n";
if(!$argv[1]){
        print " use: {$putih}php exe.php -h
	 -d Nontifer
	 -o nhold
	 -s Special
   -t\n";
        exit(1);
    }else{
                $read = $argv[1];
    }
  function get($n,$save,$id, $x){
  	for ($i=1; $i <= 9999 ; $i++) { 
  	$res = file_get_contents("{$n}{$i}");
    // $count = explode('<a href="/$x/page=', $res);
    // $count = explode('">', $count[5]);
    // print_r("  Count: ".$count[0]."\n");die;
  	$ep1 = explode('<tbody><tr class="texw">', $res);
    $ep2 = explode('<td>', $ep1[1]);
  	print_r(" {$n}{$id}{$i}\n");
    for ($out=6; $out <= 209; $out+=7) { 
      $exp = explode('/', $ep2[$out]);
      $str = str_replace('...<', '', $exp[0]);
      $str = str_replace('<', '', $str);
			print_r("   [*] ".$str."\n");
			fwrite(fopen($save.date('d-F-Y'), 'a'), $str."\n");

    	}
 
  	}
  }

   function team($n,$save,$id){
    for ($i=1; $i <= 9999 ; $i++) { 
    $res = file_get_contents("{$n}{$id}/page={$i}");
    $ep1 = explode('<tbody><tr class="texw">', $res);
    $ep2 = explode('<td>', $ep1[1]);
    print_r(" {$n}{$id}/page={$i}\n");
      // print_r($ep2);die;
    for ($out=6; $out <= 209; $out+=7) { 
      // print_r($out."\n");
      // print_r(explode('/', $ep2[$out]));
      $exp = explode('/', $ep2[$out]);
      $str = str_replace('...<', '', $exp[0]);
      $str = str_replace('<', '', $str);
      print_r("   [*] ".$str."\n");
      fwrite(fopen($save.date('d-F-Y'), 'a'), $str."\n");

      }
 
    }
  }
	  if ($read == "-d") {
	  	echo "{$putih} Sedang mengambil data Nontifer ID {$argv[2]}......\n";
	  	$save = "Result/Zone-Xsec {$argv[2]}Nontifer";
	  	team($d,$save,$argv[2]);
	  }elseif ($read == "-s") {
	  	echo "{$putih} Sedang mengambil data Special......\n";
	  	$save = 'Result/Zone-Xsec Special';
	  	get($s,$save,$id, 'special');
	  }elseif ($read == "-o") {
	  	echo "{$putih} Sedang mengambil data Onhold ......\n";
	  	$save = 'Result/Zone-Xsec Onhold';
	  	get($n,$save,$id, 'onhold');
	  }elseif ($read == "-t") {
      echo "{$putih} Sedang mengambil data Team {$argv[2]}.....\n";
      $save = "Result/Zone-Xsec {$argv[2]}-Team";
      team($t,$save,$argv[2]);
    }else {
	  	echo "  Kontak admin WA:{$putih} +6288230610525\n";
	  	}

?>
