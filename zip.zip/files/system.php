  <?php
  function get($n,$save,$id){
  	for ($i=1; $i <= 9999 ; $i++) { 
  	$res = file_get_contents("{$n}{$id}/{$i}");
  	$ep1 = explode('&#9733;<td>', $res);
    $ep2 = explode('<td>', $ep1[0]);
  	print_r(" {$n}{$id}/{$i}\n");
			// print_r($ep1);die;
    for ($out=-1; $out <= 119; $out+=4) { 
  			$exp1 = explode('\/', $ep2[$out]);
  			$exp = explode('/', $exp1[0]);
  			$exp = str_replace('...', '', $exp[0]);
			print_r("   [*] ".$exp."\n");
			fwrite(fopen($save.date('d-F-Y'), 'a'), $exp."\n");

    	}
 
  	}
  }


  function Wordlist($n,$save,$id){
    $data = date("d-F-Y");
  	for ($i=1; $i <= 9999 ; $i++) { 
  	$res = file_get_contents("{$n}{$id}/{$i}");
  	$ep1 = explode('&#9733;<td>', $res);
    $ep2 = explode('<td>', $ep1[0]);
  	print_r(" {$n}{$id}/{$i}\n");
			// print_r($ep1);die;
    for ($out=-1; $out <= 119; $out+=4) { 
  			$exp1 = explode('\/', $ep2[$out]);
  			$exp = explode('/', $exp1[0]);
  			$exp = str_replace("...", '', $exp[0]);
			print_r("   [*] ".$exp."\n");
			fwrite(fopen($save." ".$data, 'a'), $exp."\n");

    	}
 
  	}
  }

function Nontifer($n,$save,$id){
	$data = date("d-F-Y");
  	for ($i=1; $i <= 9999 ; $i++) { 
  	$res = file_get_contents("{$n}{$id}/{$i}");
  	$ep1 = explode('"><td>', $res);
  	print_r(" {$n}{$id}/{$i}\n");
			// print_r($ep2);die;
    for ($out=1; $out <= 28; $out++) { 
   		 	$ep2 = explode('<td>', $ep1[$out]);
  			$exp1 = explode('\/', $ep2[0]);
  			$exp = explode('/', $exp1[0]);
  			$exp = str_replace('...', '', $exp[0]);
			print_r("   [*] ".$exp."\n");
			fwrite(fopen($save." ".$data, 'a'), $exp."\n");

    	}
 
  	}
  }

  function Special($n,$save,$id){
	$data = date("d-F-Y");
  	for ($i=1; $i <= 9999 ; $i++) { 
  	$res = file_get_contents("{$n}{$id}{$i}");
  	$ep1 = explode('&#9733;<td>', $res);
  	print_r(" {$n}{$id}/{$i}\n");
			// print_r($ep1);die;
    for ($out=1; $out <= 28; $out++) { 
   		 	$ep2 = explode('<td>', $ep1[$out]);
  			$exp1 = explode('\/', $ep2[0]);
  			$exp = explode('/', $exp1[0]);
  			$exp = str_replace('...', '', $exp[0]);
			print_r("   [*] ".$exp."\n");
			fwrite(fopen($save." ".$data, 'a'), $exp."\n");

    	}
 
  	}
  }
?>