<?php 
error_reporting(0);
$green2="\033[1;32m";
$putih="\033[0;37m";
$d = "https://zone-d.org/attacker/id/";
$s = "https://zone-d.org/mirror/special/";
$n = "https://zone-d.org/mirror/onhold/";
echo "{$green2} 	___________________________
	< root@indoxploit:~# Zone-D >
	 ---------------------------
	   \         ,        ,
	    \       /(        )`
	     \      \ \___   / |
	            /- _  `-/  '
	           (/\/ \ \   /\
	           / /   | `    \
	           O O   ) /    |
	           `-^--'`<     '
	          (_.)  _  )   /
	           `.___/`    /
	             `-----' /
	<----.     __ / __   \
	<----|====O)))==) \) /====>
	<----'    `--' `.__,' \
	             |        |
	              \       /
	        ______( (_  / \______
	      ,'  ,-----'   |        \
	      `--{__________)        \/
\r\n";
 ?>