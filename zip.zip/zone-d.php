<?php

include('files/banner.php');
if(!$argv[1]){
        print " use: {$putih}php exe.php -h
	 -d Nontifer
	 -o nhold
	 -s Special
	 -dl Nontifer Wordlist\n";
        exit(1);
    }else{
                $read = $argv[1];
    }
include('files/system.php');
	  if ($read == "-d") {
	  	echo "{$putih} Sedang mengambil data Nontifer ID {$argv[2]}......\n";
	  	$save = "Result/Zone-d {$argv[2]}-Nontifer";
	  	Nontifer($d,$save,$argv[2]);
	  }elseif ($read == "-s") {
	  	echo "{$putih} Sedang mengambil data Special......\n";
	  	$save = 'Result/Zone-d Special';
	  	Special($s,$save,$id);
	  }elseif ($read == "-o") {
	  	echo "{$putih} Sedang mengambil data Onhold ......\n";
	  	$save = 'Result/Zone-d Onhold';
	  	get($n,$save,$id);
	  }else {
	  	echo "  Kontak admin WA:{$putih} +6288230610525\n";
	  	}

?>